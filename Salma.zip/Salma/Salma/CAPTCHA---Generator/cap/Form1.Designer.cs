﻿namespace CaptchaGenerator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPageTextCaptcha = new TabPage();
            buttonRefreshTextCaptcha = new Button();
            buttonValidateTextCaptcha = new Button();
            textBoxTextCaptchaInput = new TextBox();
            labelTextCaptchaInstruction = new Label();
            pictureBoxTextCaptcha = new PictureBox();
            tabPageImageCaptcha = new TabPage();
            buttonRefreshImageCaptcha = new Button();
            buttonValidateImageCaptcha = new Button();
            flowLayoutPanelImageCaptcha = new FlowLayoutPanel();
            labelImageCaptchaInstruction = new Label();
            tabPageMathCaptcha = new TabPage();
            buttonRefreshMathCaptcha = new Button();
            buttonValidateMathCaptcha = new Button();
            textBoxMathCaptchaInput = new TextBox();
            labelMathCaptchaInstruction = new Label();
            labelMathCaptcha = new Label();
            tabPageCheckboxCaptcha = new TabPage();
            labelCheckboxStatus = new Label();
            buttonRefreshCheckboxCaptcha = new Button();
            buttonValidateCheckboxCaptcha = new Button();
            checkBoxRecaptcha = new CheckBox();
            label1 = new Label();
            tabControl1.SuspendLayout();
            tabPageTextCaptcha.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxTextCaptcha).BeginInit();
            tabPageImageCaptcha.SuspendLayout();
            tabPageMathCaptcha.SuspendLayout();
            tabPageCheckboxCaptcha.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPageTextCaptcha);
            tabControl1.Controls.Add(tabPageImageCaptcha);
            tabControl1.Controls.Add(tabPageMathCaptcha);
            tabControl1.Controls.Add(tabPageCheckboxCaptcha);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(4, 5, 4, 5);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(779, 709);
            tabControl1.TabIndex = 0;
            // 
            // tabPageTextCaptcha
            // 
            tabPageTextCaptcha.Controls.Add(buttonRefreshTextCaptcha);
            tabPageTextCaptcha.Controls.Add(buttonValidateTextCaptcha);
            tabPageTextCaptcha.Controls.Add(textBoxTextCaptchaInput);
            tabPageTextCaptcha.Controls.Add(labelTextCaptchaInstruction);
            tabPageTextCaptcha.Controls.Add(pictureBoxTextCaptcha);
            tabPageTextCaptcha.Location = new Point(4, 29);
            tabPageTextCaptcha.Margin = new Padding(4, 5, 4, 5);
            tabPageTextCaptcha.Name = "tabPageTextCaptcha";
            tabPageTextCaptcha.Padding = new Padding(4, 5, 4, 5);
            tabPageTextCaptcha.Size = new Size(771, 676);
            tabPageTextCaptcha.TabIndex = 0;
            tabPageTextCaptcha.Text = "Text CAPTCHA";
            tabPageTextCaptcha.UseVisualStyleBackColor = true;
            // 
            // buttonRefreshTextCaptcha
            // 
            buttonRefreshTextCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonRefreshTextCaptcha.Location = new Point(279, 425);
            buttonRefreshTextCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonRefreshTextCaptcha.Name = "buttonRefreshTextCaptcha";
            buttonRefreshTextCaptcha.Size = new Size(208, 54);
            buttonRefreshTextCaptcha.TabIndex = 4;
            buttonRefreshTextCaptcha.Text = "Refresh";
            buttonRefreshTextCaptcha.UseVisualStyleBackColor = true;
            buttonRefreshTextCaptcha.Click += buttonRefreshTextCaptcha_Click;
            // 
            // buttonValidateTextCaptcha
            // 
            buttonValidateTextCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonValidateTextCaptcha.Location = new Point(279, 345);
            buttonValidateTextCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonValidateTextCaptcha.Name = "buttonValidateTextCaptcha";
            buttonValidateTextCaptcha.Size = new Size(208, 54);
            buttonValidateTextCaptcha.TabIndex = 3;
            buttonValidateTextCaptcha.Text = "Validate";
            buttonValidateTextCaptcha.UseVisualStyleBackColor = true;
            buttonValidateTextCaptcha.Click += buttonValidateTextCaptcha_Click;
            // 
            // textBoxTextCaptchaInput
            // 
            textBoxTextCaptchaInput.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxTextCaptchaInput.Location = new Point(252, 275);
            textBoxTextCaptchaInput.Margin = new Padding(4, 5, 4, 5);
            textBoxTextCaptchaInput.Name = "textBoxTextCaptchaInput";
            textBoxTextCaptchaInput.Size = new Size(260, 30);
            textBoxTextCaptchaInput.TabIndex = 2;
            // 
            // labelTextCaptchaInstruction
            // 
            labelTextCaptchaInstruction.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelTextCaptchaInstruction.Location = new Point(11, 54);
            labelTextCaptchaInstruction.Margin = new Padding(4, 0, 4, 0);
            labelTextCaptchaInstruction.Name = "labelTextCaptchaInstruction";
            labelTextCaptchaInstruction.Size = new Size(747, 35);
            labelTextCaptchaInstruction.TabIndex = 1;
            labelTextCaptchaInstruction.Text = "Enter the characters you see in the image below";
            labelTextCaptchaInstruction.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBoxTextCaptcha
            // 
            pictureBoxTextCaptcha.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxTextCaptcha.Location = new Point(252, 111);
            pictureBoxTextCaptcha.Margin = new Padding(4, 5, 4, 5);
            pictureBoxTextCaptcha.Name = "pictureBoxTextCaptcha";
            pictureBoxTextCaptcha.Size = new Size(261, 137);
            pictureBoxTextCaptcha.TabIndex = 0;
            pictureBoxTextCaptcha.TabStop = false;
            // 
            // tabPageImageCaptcha
            // 
            tabPageImageCaptcha.Controls.Add(buttonRefreshImageCaptcha);
            tabPageImageCaptcha.Controls.Add(buttonValidateImageCaptcha);
            tabPageImageCaptcha.Controls.Add(flowLayoutPanelImageCaptcha);
            tabPageImageCaptcha.Controls.Add(labelImageCaptchaInstruction);
            tabPageImageCaptcha.Location = new Point(4, 29);
            tabPageImageCaptcha.Margin = new Padding(4, 5, 4, 5);
            tabPageImageCaptcha.Name = "tabPageImageCaptcha";
            tabPageImageCaptcha.Padding = new Padding(4, 5, 4, 5);
            tabPageImageCaptcha.Size = new Size(771, 676);
            tabPageImageCaptcha.TabIndex = 1;
            tabPageImageCaptcha.Text = "Image CAPTCHA";
            tabPageImageCaptcha.UseVisualStyleBackColor = true;
            // 
            // buttonRefreshImageCaptcha
            // 
            buttonRefreshImageCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonRefreshImageCaptcha.Location = new Point(279, 597);
            buttonRefreshImageCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonRefreshImageCaptcha.Name = "buttonRefreshImageCaptcha";
            buttonRefreshImageCaptcha.Size = new Size(208, 54);
            buttonRefreshImageCaptcha.TabIndex = 5;
            buttonRefreshImageCaptcha.Text = "Refresh";
            buttonRefreshImageCaptcha.UseVisualStyleBackColor = true;
            buttonRefreshImageCaptcha.Click += buttonRefreshImageCaptcha_Click;
            // 
            // buttonValidateImageCaptcha
            // 
            buttonValidateImageCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonValidateImageCaptcha.Location = new Point(279, 534);
            buttonValidateImageCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonValidateImageCaptcha.Name = "buttonValidateImageCaptcha";
            buttonValidateImageCaptcha.Size = new Size(208, 54);
            buttonValidateImageCaptcha.TabIndex = 4;
            buttonValidateImageCaptcha.Text = "Validate";
            buttonValidateImageCaptcha.UseVisualStyleBackColor = true;
            buttonValidateImageCaptcha.Click += buttonValidateImageCaptcha_Click;
            // 
            // flowLayoutPanelImageCaptcha
            // 
            flowLayoutPanelImageCaptcha.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanelImageCaptcha.Location = new Point(197, 71);
            flowLayoutPanelImageCaptcha.Margin = new Padding(4, 5, 4, 5);
            flowLayoutPanelImageCaptcha.Name = "flowLayoutPanelImageCaptcha";
            flowLayoutPanelImageCaptcha.Size = new Size(375, 433);
            flowLayoutPanelImageCaptcha.TabIndex = 3;
            // 
            // labelImageCaptchaInstruction
            // 
            labelImageCaptchaInstruction.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelImageCaptchaInstruction.Location = new Point(11, 43);
            labelImageCaptchaInstruction.Margin = new Padding(4, 0, 4, 0);
            labelImageCaptchaInstruction.Name = "labelImageCaptchaInstruction";
            labelImageCaptchaInstruction.Size = new Size(747, 35);
            labelImageCaptchaInstruction.TabIndex = 2;
            labelImageCaptchaInstruction.Text = "Select all squares that contain ...";
            labelImageCaptchaInstruction.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tabPageMathCaptcha
            // 
            tabPageMathCaptcha.Controls.Add(buttonRefreshMathCaptcha);
            tabPageMathCaptcha.Controls.Add(buttonValidateMathCaptcha);
            tabPageMathCaptcha.Controls.Add(textBoxMathCaptchaInput);
            tabPageMathCaptcha.Controls.Add(labelMathCaptchaInstruction);
            tabPageMathCaptcha.Controls.Add(labelMathCaptcha);
            tabPageMathCaptcha.Location = new Point(4, 29);
            tabPageMathCaptcha.Margin = new Padding(4, 5, 4, 5);
            tabPageMathCaptcha.Name = "tabPageMathCaptcha";
            tabPageMathCaptcha.Size = new Size(771, 676);
            tabPageMathCaptcha.TabIndex = 2;
            tabPageMathCaptcha.Text = "Math CAPTCHA";
            tabPageMathCaptcha.UseVisualStyleBackColor = true;
            // 
            // buttonRefreshMathCaptcha
            // 
            buttonRefreshMathCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonRefreshMathCaptcha.Location = new Point(279, 425);
            buttonRefreshMathCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonRefreshMathCaptcha.Name = "buttonRefreshMathCaptcha";
            buttonRefreshMathCaptcha.Size = new Size(208, 54);
            buttonRefreshMathCaptcha.TabIndex = 9;
            buttonRefreshMathCaptcha.Text = "Refresh";
            buttonRefreshMathCaptcha.UseVisualStyleBackColor = true;
            buttonRefreshMathCaptcha.Click += buttonRefreshMathCaptcha_Click;
            // 
            // buttonValidateMathCaptcha
            // 
            buttonValidateMathCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonValidateMathCaptcha.Location = new Point(279, 345);
            buttonValidateMathCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonValidateMathCaptcha.Name = "buttonValidateMathCaptcha";
            buttonValidateMathCaptcha.Size = new Size(208, 54);
            buttonValidateMathCaptcha.TabIndex = 8;
            buttonValidateMathCaptcha.Text = "Validate";
            buttonValidateMathCaptcha.UseVisualStyleBackColor = true;
            buttonValidateMathCaptcha.Click += buttonValidateMathCaptcha_Click;
            // 
            // textBoxMathCaptchaInput
            // 
            textBoxMathCaptchaInput.Font = new Font("Microsoft Sans Serif", 12F);
            textBoxMathCaptchaInput.Location = new Point(252, 275);
            textBoxMathCaptchaInput.Margin = new Padding(4, 5, 4, 5);
            textBoxMathCaptchaInput.Name = "textBoxMathCaptchaInput";
            textBoxMathCaptchaInput.Size = new Size(260, 30);
            textBoxMathCaptchaInput.TabIndex = 7;
            // 
            // labelMathCaptchaInstruction
            // 
            labelMathCaptchaInstruction.Font = new Font("Microsoft Sans Serif", 9.75F);
            labelMathCaptchaInstruction.Location = new Point(11, 54);
            labelMathCaptchaInstruction.Margin = new Padding(4, 0, 4, 0);
            labelMathCaptchaInstruction.Name = "labelMathCaptchaInstruction";
            labelMathCaptchaInstruction.Size = new Size(747, 35);
            labelMathCaptchaInstruction.TabIndex = 6;
            labelMathCaptchaInstruction.Text = "Complete the following math operation";
            labelMathCaptchaInstruction.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labelMathCaptcha
            // 
            labelMathCaptcha.BorderStyle = BorderStyle.FixedSingle;
            labelMathCaptcha.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelMathCaptcha.Location = new Point(252, 111);
            labelMathCaptcha.Margin = new Padding(4, 0, 4, 0);
            labelMathCaptcha.Name = "labelMathCaptcha";
            labelMathCaptcha.Size = new Size(261, 137);
            labelMathCaptcha.TabIndex = 5;
            labelMathCaptcha.Text = "8 + 7 = ?";
            labelMathCaptcha.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // tabPageCheckboxCaptcha
            // 
            tabPageCheckboxCaptcha.Controls.Add(labelCheckboxStatus);
            tabPageCheckboxCaptcha.Controls.Add(buttonRefreshCheckboxCaptcha);
            tabPageCheckboxCaptcha.Controls.Add(buttonValidateCheckboxCaptcha);
            tabPageCheckboxCaptcha.Controls.Add(checkBoxRecaptcha);
            tabPageCheckboxCaptcha.Controls.Add(label1);
            tabPageCheckboxCaptcha.Location = new Point(4, 29);
            tabPageCheckboxCaptcha.Margin = new Padding(4, 5, 4, 5);
            tabPageCheckboxCaptcha.Name = "tabPageCheckboxCaptcha";
            tabPageCheckboxCaptcha.Size = new Size(771, 676);
            tabPageCheckboxCaptcha.TabIndex = 3;
            tabPageCheckboxCaptcha.Text = "Checkbox CAPTCHA";
            tabPageCheckboxCaptcha.UseVisualStyleBackColor = true;
            // 
            // labelCheckboxStatus
            // 
            labelCheckboxStatus.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelCheckboxStatus.Location = new Point(11, 262);
            labelCheckboxStatus.Margin = new Padding(4, 0, 4, 0);
            labelCheckboxStatus.Name = "labelCheckboxStatus";
            labelCheckboxStatus.Size = new Size(747, 35);
            labelCheckboxStatus.TabIndex = 13;
            labelCheckboxStatus.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // buttonRefreshCheckboxCaptcha
            // 
            buttonRefreshCheckboxCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonRefreshCheckboxCaptcha.Location = new Point(279, 425);
            buttonRefreshCheckboxCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonRefreshCheckboxCaptcha.Name = "buttonRefreshCheckboxCaptcha";
            buttonRefreshCheckboxCaptcha.Size = new Size(208, 54);
            buttonRefreshCheckboxCaptcha.TabIndex = 12;
            buttonRefreshCheckboxCaptcha.Text = "Reset";
            buttonRefreshCheckboxCaptcha.UseVisualStyleBackColor = true;
            buttonRefreshCheckboxCaptcha.Click += buttonRefreshCheckboxCaptcha_Click;
            // 
            // buttonValidateCheckboxCaptcha
            // 
            buttonValidateCheckboxCaptcha.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonValidateCheckboxCaptcha.Location = new Point(279, 345);
            buttonValidateCheckboxCaptcha.Margin = new Padding(4, 5, 4, 5);
            buttonValidateCheckboxCaptcha.Name = "buttonValidateCheckboxCaptcha";
            buttonValidateCheckboxCaptcha.Size = new Size(208, 54);
            buttonValidateCheckboxCaptcha.TabIndex = 11;
            buttonValidateCheckboxCaptcha.Text = "Validate";
            buttonValidateCheckboxCaptcha.UseVisualStyleBackColor = true;
            buttonValidateCheckboxCaptcha.Click += buttonValidateCheckboxCaptcha_Click;
            // 
            // checkBoxRecaptcha
            // 
            checkBoxRecaptcha.Appearance = Appearance.Button;
            checkBoxRecaptcha.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxRecaptcha.Location = new Point(252, 168);
            checkBoxRecaptcha.Margin = new Padding(4, 5, 4, 5);
            checkBoxRecaptcha.Name = "checkBoxRecaptcha";
            checkBoxRecaptcha.Size = new Size(261, 74);
            checkBoxRecaptcha.TabIndex = 10;
            checkBoxRecaptcha.Text = "I'm not a robot";
            checkBoxRecaptcha.TextAlign = ContentAlignment.MiddleCenter;
            checkBoxRecaptcha.UseVisualStyleBackColor = true;
            checkBoxRecaptcha.CheckedChanged += checkBoxRecaptcha_CheckedChanged;
            // 
            // label1
            // 
            label1.Font = new Font("Microsoft Sans Serif", 9.75F);
            label1.Location = new Point(11, 54);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(747, 74);
            label1.TabIndex = 7;
            label1.Text = "To continue, please verify you are human by checking the box below";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(779, 709);
            Controls.Add(tabControl1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CAPTCHA Generator";
            tabControl1.ResumeLayout(false);
            tabPageTextCaptcha.ResumeLayout(false);
            tabPageTextCaptcha.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxTextCaptcha).EndInit();
            tabPageImageCaptcha.ResumeLayout(false);
            tabPageMathCaptcha.ResumeLayout(false);
            tabPageMathCaptcha.PerformLayout();
            tabPageCheckboxCaptcha.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageTextCaptcha;
        private System.Windows.Forms.TabPage tabPageImageCaptcha;
        private System.Windows.Forms.TabPage tabPageMathCaptcha;
        private System.Windows.Forms.TabPage tabPageCheckboxCaptcha;
        private System.Windows.Forms.PictureBox pictureBoxTextCaptcha;
        private System.Windows.Forms.Label labelTextCaptchaInstruction;
        private System.Windows.Forms.Button buttonRefreshTextCaptcha;
        private System.Windows.Forms.Button buttonValidateTextCaptcha;
        private System.Windows.Forms.TextBox textBoxTextCaptchaInput;
        private System.Windows.Forms.Label labelImageCaptchaInstruction;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelImageCaptcha;
        private System.Windows.Forms.Button buttonRefreshImageCaptcha;
        private System.Windows.Forms.Button buttonValidateImageCaptcha;
        private System.Windows.Forms.Label labelMathCaptchaInstruction;
        private System.Windows.Forms.Label labelMathCaptcha;
        private System.Windows.Forms.Button buttonRefreshMathCaptcha;
        private System.Windows.Forms.Button buttonValidateMathCaptcha;
        private System.Windows.Forms.TextBox textBoxMathCaptchaInput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxRecaptcha;
        private System.Windows.Forms.Button buttonRefreshCheckboxCaptcha;
        private System.Windows.Forms.Button buttonValidateCheckboxCaptcha;
        private System.Windows.Forms.Label labelCheckboxStatus;
    }
}