﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace CaptchaGenerator
{
    public partial class Form1 : Form
    {
        private string currentTextCaptcha = "";
        private string currentMathCaptcha = "";
        private int mathCaptchaResult = 0;
        private bool isCheckboxVerified = false;
        private Random random = new Random();
        private string[] imageCaptchaAnswers = { "car", "bicycle", "traffic light", "bus", "crosswalk" };
        private string currentImageCaptchaAnswer = "";

        public Form1()
        {
            InitializeComponent();

            // Set tab titles
            tabControl1.TabPages[0].Text = "Text CAPTCHA";
            tabControl1.TabPages[1].Text = "Image CAPTCHA";
            tabControl1.TabPages[2].Text = "Math CAPTCHA";
            tabControl1.TabPages[3].Text = "Checkbox CAPTCHA";

            // Generate all CAPTCHA types
            GenerateTextCaptcha();
            GenerateMathCaptcha();
            SetupImageCaptcha();
        }

        #region Text CAPTCHA Methods
        private void GenerateTextCaptcha()
        {
            // Generate random 6-character CAPTCHA text
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
            char[] stringChars = new char[6];

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            currentTextCaptcha = new string(stringChars);

            // Create image with the text
            Bitmap captchaImage = new Bitmap(pictureBoxTextCaptcha.Width, pictureBoxTextCaptcha.Height);
            using (Graphics g = Graphics.FromImage(captchaImage))
            {
                // Set white background
                g.Clear(Color.White);

                // Add random lines and shapes for noise
                for (int i = 0; i < 10; i++)
                {
                    int x1 = random.Next(captchaImage.Width);
                    int y1 = random.Next(captchaImage.Height);
                    int x2 = random.Next(captchaImage.Width);
                    int y2 = random.Next(captchaImage.Height);
                    g.DrawLine(new Pen(Color.LightGray), x1, y1, x2, y2);
                }

                // Draw the text
                using (GraphicsPath path = new GraphicsPath())
                {
                    using (Font font = new Font("Arial", 22, FontStyle.Bold))
                    {
                        path.AddString(currentTextCaptcha, font.FontFamily, (int)font.Style, font.Size, new Point(10, 10), StringFormat.GenericDefault);
                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        // Slightly distort the text
                        Matrix matrix = new Matrix();
                        matrix.Shear((float)random.NextDouble() * 0.2f, (float)random.NextDouble() * 0.2f);
                        path.Transform(matrix);

                        // Draw text in dark blue
                        g.FillPath(new SolidBrush(Color.Navy), path);
                        g.DrawPath(new Pen(Color.Black), path);
                    }
                }
            }

            // Set the image to PictureBox
            if (pictureBoxTextCaptcha.Image != null)
            {
                pictureBoxTextCaptcha.Image.Dispose();
            }
            pictureBoxTextCaptcha.Image = captchaImage;
            textBoxTextCaptchaInput.Clear();
        }

        private void buttonValidateTextCaptcha_Click(object sender, EventArgs e)
        {
            if (textBoxTextCaptchaInput.Text.Trim() == currentTextCaptcha)
            {
                MessageBox.Show("Verification successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Incorrect code, please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonRefreshTextCaptcha_Click(object sender, EventArgs e)
        {
            GenerateTextCaptcha();
        }
        #endregion

        #region Image CAPTCHA Methods
        private void SetupImageCaptcha()
        {
            currentImageCaptchaAnswer = imageCaptchaAnswers[random.Next(imageCaptchaAnswers.Length)];
            labelImageCaptchaInstruction.Text = $"Select all squares that contain {currentImageCaptchaAnswer}";

            // Create grid of squares
            flowLayoutPanelImageCaptcha.Controls.Clear();
            for (int i = 0; i < 9; i++)
            {
                CheckBox checkBox = new CheckBox();
                checkBox.Appearance = Appearance.Button;
                checkBox.TextAlign = ContentAlignment.MiddleCenter;
                checkBox.Size = new Size(90, 90);
                checkBox.BackColor = Color.LightGray;
                checkBox.Text = ""; // In a real app, images would be used instead of text
                checkBox.Tag = random.Next(10) < 3; // 30% chance the square contains the required object

                // In a real app, you would use actual images here
                if ((bool)checkBox.Tag)
                {
                    checkBox.BackColor = Color.LightBlue;
                    checkBox.Text = "[Image of " + currentImageCaptchaAnswer + "]";
                }
                else
                {
                    int randomIndex = random.Next(imageCaptchaAnswers.Length);
                    while (imageCaptchaAnswers[randomIndex] == currentImageCaptchaAnswer)
                        randomIndex = random.Next(imageCaptchaAnswers.Length);

                    checkBox.Text = "[Image of " + imageCaptchaAnswers[randomIndex] + "]";
                }

                flowLayoutPanelImageCaptcha.Controls.Add(checkBox);
            }
        }

        private void buttonValidateImageCaptcha_Click(object sender, EventArgs e)
        {
            bool allCorrect = true;

            foreach (Control control in flowLayoutPanelImageCaptcha.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    bool shouldBeSelected = (bool)checkBox.Tag;
                    if (checkBox.Checked != shouldBeSelected)
                    {
                        allCorrect = false;
                        break;
                    }
                }
            }

            if (allCorrect)
            {
                MessageBox.Show("Verification successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Incorrect selection, please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonRefreshImageCaptcha_Click(object sender, EventArgs e)
        {
            SetupImageCaptcha();
        }
        #endregion

        #region Math CAPTCHA Methods
        private void GenerateMathCaptcha()
        {
            // Generate simple math operation
            int a = random.Next(1, 20);
            int b = random.Next(1, 10);
            string[] operations = { "+", "-", "×" };
            string operation = operations[random.Next(operations.Length)];

            switch (operation)
            {
                case "+":
                    mathCaptchaResult = a + b;
                    break;
                case "-":
                    // Avoid negative numbers
                    if (a < b)
                    {
                        int temp = a;
                        a = b;
                        b = temp;
                    }
                    mathCaptchaResult = a - b;
                    break;
                case "×":
                    mathCaptchaResult = a * b;
                    break;
            }

            currentMathCaptcha = $"{a} {operation} {b} = ?";
            labelMathCaptcha.Text = currentMathCaptcha;
            textBoxMathCaptchaInput.Clear();
        }

        private void buttonValidateMathCaptcha_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxMathCaptchaInput.Text.Trim(), out int userAnswer) && userAnswer == mathCaptchaResult)
            {
                MessageBox.Show("Verification successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Incorrect answer, please try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonRefreshMathCaptcha_Click(object sender, EventArgs e)
        {
            GenerateMathCaptcha();
        }
        #endregion

        #region Checkbox CAPTCHA Methods
        private void checkBoxRecaptcha_CheckedChanged(object sender, EventArgs e)
        {
            // Simulate human verification with random probability
            if (checkBoxRecaptcha.Checked)
            {
                // Normally this would check various factors like mouse movement and user behavior
                isCheckboxVerified = random.Next(100) < 90; // 90% success probability

                if (isCheckboxVerified)
                {
                    labelCheckboxStatus.Text = "Verification successful";
                    labelCheckboxStatus.ForeColor = Color.Green;
                }
                else
                {
                    labelCheckboxStatus.Text = "Verification failed, please try again";
                    labelCheckboxStatus.ForeColor = Color.Red;
                    checkBoxRecaptcha.Checked = false;
                }
            }
            else
            {
                labelCheckboxStatus.Text = "";
                isCheckboxVerified = false;
            }
        }

        private void buttonValidateCheckboxCaptcha_Click(object sender, EventArgs e)
        {
            if (isCheckboxVerified)
            {
                MessageBox.Show("Verification successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please check the box first to verify", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonRefreshCheckboxCaptcha_Click(object sender, EventArgs e)
        {
            checkBoxRecaptcha.Checked = false;
            labelCheckboxStatus.Text = "";
            isCheckboxVerified = false;
        }
        #endregion
    }
}